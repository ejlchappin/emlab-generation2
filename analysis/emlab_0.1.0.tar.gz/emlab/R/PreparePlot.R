CreateSegmentPlot <- function(filename, title, data, x, y, group, n, xlabel, ylabel, legend, labels) {

  library(ggplot2)
  library(RColorBrewer)

  plot <- ggplot(data) +
    geom_line(aes(x=data[[x]], y=data[[y]], colour=(data[[group]])), size=1, alpha=.8, show.legend = FALSE) +
    scale_colour_manual(values = rev(colorRampPalette(brewer.pal(9, "RdYlGn"))(n))) +
    labs(title=title, y=ylabel, x=xlabel, colour=legend) +
    theme_minimal() +
    #theme(legend.position="bottom") +
    #guides(color=guide_legend(nrow=ceiling(n/10), byrow=FALSE)) +
    #theme(legend.text=element_text(size=rel(0.7))) +
    scale_x_continuous(breaks = seq(0, max(data[[x]]), by=4)) +
    scale_y_continuous(labels=function(x) format(x, big.mark = ".", decimal.mark = ",", scientific = FALSE))

  ggsave(paste(filename, ".png",sep=""), width = 8, height = 5)
  message(paste("Plot '", filename, "' added to your working directory", sep=""))
  return(plot)
}

CreateBareSegmentPlot <- function(filename, title, data, x, y, group, n, xlabel, ylabel, legend, labels) {

  library(ggplot2)
  library(RColorBrewer)

  plot <- ggplot(data) +
    geom_line(aes(x=data[[x]], y=data[[y]], colour=(data[[group]])), size=1, alpha=.8, show.legend = FALSE) +
    scale_colour_manual(values = c("black",rev(colorRampPalette(brewer.pal(9, "RdYlGn"))(n)))) +
    labs(title=title, y=ylabel, x=xlabel, colour=legend) +
    theme_minimal() +
    #theme(legend.position="bottom") +
    #guides(color=guide_legend(nrow=ceiling(n/10), byrow=FALSE)) +
    #theme(legend.text=element_text(size=rel(0.7))) +
    scale_x_continuous(breaks = seq(0, max(data[[x]]), by=4)) +
    scale_y_continuous(labels=function(x) format(x, big.mark = ".", decimal.mark = ",", scientific = FALSE))

  return(plot)
}

CreateStackedPlot <- function(filename, title, data, x, y, group, n, xlabel, ylabel, legend) {

  library(ggplot2)
  library(RColorBrewer)

  plot <- ggplot(data, aes(x=data[[x]], y=data[[y]], fill=data[[group]])) +
    geom_area(colour="black", size=.2, alpha=.6) +
    scale_fill_manual(values = colorRampPalette(brewer.pal(9, "Set1"))(n)) +
    labs(title=title, y=ylabel, x=xlabel, fill=legend) +
    theme_minimal() +
    scale_x_continuous(breaks = seq(0, max(data[[x]]), by=4)) +
    scale_y_continuous(labels=function(x) format(x, big.mark = ".", decimal.mark = ",", scientific = FALSE))

  ggsave(paste(filename, ".png",sep=""), width = 8, height = 5)
  message(paste("Plot '", filename, "' added to your working directory", sep=""))
  return(plot)
}
