#' Plot duration of the simulation of a run in a ribbon plot
#' @description Example query: PlotDuration(data)
#' @param data Dataframe of which to take duration data.
#' @return Saves plots in workspace automatically.
#' @return Also a ggplot object. Can be stored and accessed by user for further ggplot manipulation.
#' @export
PlotDuration <- function(data) {

  headers = GetHeaders(data)
  cIter = ColumnIteration(headers)
  cTick = ColumnTicks(headers)
  cDuration = ColumnDurations(headers)
  sData <- data[,c(cIter,cTick,cDuration)]

  # Retrieve values for min, max and average and add them to dataframe 'pData'
  min <- aggregate.data.frame(sData,by=list(sData$tick), FUN = min, na.rm = TRUE)
  max <- aggregate.data.frame(sData,by=list(sData$tick), FUN = max, na.rm = TRUE)
  pData <- aggregate.data.frame(sData,by=list(sData$tick), FUN = mean, na.rm = TRUE)
  pData["min"] <- min$duration
  pData["max"] <- max$duration

  plotname = "Simulation duration"
  title = "Duration of simulation in seconds"
  xlabel = "Tick (year)"
  ylabel = "Duration (seconds)"

  # Create plot
  plotobject <- ggplot(pData, aes(x=tick, y=duration, ymin=min, ymax=max)) +
    geom_ribbon(fill="dodgerblue", alpha=.6) +
    geom_line(colour="black", size=1) +
    labs(title =title, y=ylabel, x=xlabel) +
    theme_minimal()

  ggsave(paste(plotname, ".png",sep=""), plot=plotobject, width=8, height=5)
  message(paste("Plot '", plotname, "' added to your working directory", sep=""))

  return(plotobject)
}
