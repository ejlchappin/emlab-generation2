#' Get the column number in data containing the iteration variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the iteration variable
#' @export
ColumnIteration <- function(headers) {

  cIteration = as.numeric(which(grepl("iteration", headers$variables))[1])
  return(cIteration)
}


#' Get the column number in data containing the tick variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the tick variable
#' @export
ColumnTicks <- function(headers) {

  cTick = as.numeric(which(grepl("tick", headers$variables))[1])
  return(cTick)
}


#' Get the column number in data containing the duration variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the duration variable
#' @export
ColumnDurations <- function(headers) {

  cDuration =  as.numeric(which(grepl("duration", headers$variables))[1])
  return(cDuration)
}


#' Get the column number in data containing the nr-of-power-plants variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the nr-of-power-plants variable
#' @export
ColumnNrPowerPlants <- function(headers) {

  cNrPowerPlants = as.numeric(which(grepl("nr.of.powerplants", headers$variables))[1])
  return(cNrPowerPlants)
}


#' Get the column number in data containing the avg-start-of-construction variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the avg-start-of-construction variable
#' @export
ColumnAvgStartConstructing <- function(headers) {

  cAvgStartConstructing = as.numeric(which(grepl("average.start.constructing.operational.plants", headers$variables))[1])
  return(cAvgStartConstructing)
}
