# -----------------------------------------------------------------------------------
# MAIN FUNCTION: Decision logic for substance volume plotting
# -----------------------------------------------------------------------------------

#' Plot substance volumes over a simulation in ribbon plots
#' @description Example query: PlotSubstanceVolume(data)
#' @param data Dataframe of which to take substance volume data.
#' @return Saves plots in workspace automatically.
#' @return Also a ggplot object. Can be stored and accessed by user for further ggplot manipulation.
#' @export
PlotSubstanceVolume <- function(data) {

  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)

  if(nMarkets == 1) {
    PlotSubstanceVolumeOneMarket(data, headers)
  }  else {
    PlotSubstanceVolumeOneMarket(data, headers)
  }
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 1: One market
# -----------------------------------------------------------------------------------

PlotSubstanceVolumeOneMarket <- function(data, headers) {


  cIter = ColumnIteration(headers)
  cTick = ColumnTicks(headers)
  cSubstance = ColumnVolumeSubstance(headers)
  nSubstances = NumberSubstances(headers)
  vSubstance = VectorSubstances(headers)
  vMarket = VectorMarkets(headers)
  nMarket = NumberMarkets(headers)

  # Create empty list in which to store plots to return to user
  iplots <- list()
  for(i in 1:nSubstances) {
    sData <- data[,c(cIter,cTick, (cSubstance+2*i-2))]

    # Retrieve values for min, max and average and add them to dataframe 'pData'
    min <- aggregate.data.frame(sData,by=list(sData$tick), FUN = min, na.rm = TRUE)
    max <- aggregate.data.frame(sData,by=list(sData$tick), FUN = max, na.rm = TRUE)
    pData <- aggregate.data.frame(sData,by=list(sData$tick), FUN = mean, na.rm = TRUE)
    pData["min"] <- min[4]
    pData["max"] <- max[4]

    if (nMarket == 1) {
      plotname = paste("Volume of ", vSubstance[i], " in ", vMarket[1], sep="")
      title = paste("Volume of ", vSubstance[i], " in ", vMarket[1], sep="")
    } else {
      plotname = paste("Volume of ", vSubstance[i], " in ", vMarket[1], " and ", vMarket[2], sep="")
      title = paste("Volume of ", vSubstance[i], " in ", vMarket[1], " and ", vMarket[2], sep="")
    }

    xlabel = "Tick (year)"
    ylabel = "Volume"

    # Create plot
    plotobject <- ggplot(pData, aes(x=tick, y=pData[[4]], ymin=min, ymax=max)) +
      geom_ribbon(fill="dodgerblue", alpha=.6) +
      geom_line(colour="black", size=1) +
      labs(title =title, y=ylabel, x=xlabel) +
      theme_minimal()

    iplots[[i]] <- plotobject

    ggsave(paste(plotname, ".png",sep=""), plot=plotobject, width=8, height=5)
    message(paste("Plot '", plotname, "' added to your working directory", sep=""))

  }
  return(iplots)
}
