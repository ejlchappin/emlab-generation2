#' Plot costs incurred by agents in simulation by cost type
#' @description Example query: PlotCosts(data)
#' @param data Dataframe of which to take cost data.
#' @return Saves plots in workspace automatically.
#' @return Also a ggplot object. Can be stored and accessed by user for further ggplot manipulation.
#' @export
PlotCosts <- function(data) {
  message("Plotting expenditures")

  # Working variables
  headers = GetHeaders(data)
  vMarkets = VectorMarkets(headers)
  cTick = ColumnTicks(headers)
  cIteration = ColumnIteration(headers)
  nIterations = max(data[cIteration])

  cFixed = ColumnFlowFixedCost(headers)
  cVariable = ColumnFlowCommodity(headers)
  cLoan = ColumnFlowLoan(headers)
  cCO2Auction = ColumnFlowCO2Auction(headers)
  cCO2Tax = ColumnFlowCO2Tax(headers)
  cCO2NatMin = ColumnFlownNationalMinCO2(headers)

  # For each of the expenses aggregate over iterations and add to a plotdata dataframe
  sFixData <- data[,c(cIteration,cTick, cFixed)]
  aFixData <- aggregate.data.frame(sFixData,by=list(sFixData$tick), FUN = mean, na.rm = TRUE)
  colnames(aFixData)[4] <- "cost"
  aFixData$type="Fixed costs"

  sVarData <- data[,c(cIteration,cTick, cVariable)]
  aVarData <- aggregate.data.frame(sVarData,by=list(sVarData$tick), FUN = mean, na.rm = TRUE)
  colnames(aVarData)[4] <- "cost"
  aVarData$type="Fuel costs"

  sLoaData <- data[,c(cIteration,cTick, cLoan)]
  aLoaData <- aggregate.data.frame(sLoaData,by=list(sLoaData$tick), FUN = mean, na.rm = TRUE)
  colnames(aLoaData)[4] <- "cost"
  aLoaData$type="Loans"

  sAucData <- data[,c(cIteration,cTick, cCO2Auction)]
  aAucData <- aggregate.data.frame(sAucData,by=list(sAucData$tick), FUN = mean, na.rm = TRUE)
  colnames(aAucData)[4] <- "cost"
  aAucData$type="CO2 Auction"

  sTaxData <- data[,c(cIteration,cTick, cCO2Tax)]
  aTaxData <- aggregate.data.frame(sTaxData,by=list(sTaxData$tick), FUN = mean, na.rm = TRUE)
  colnames(aTaxData)[4] <- "cost"
  aTaxData$type="CO2 Tax"

  sMinData <- data[,c(cIteration,cTick, cCO2NatMin)]
  aMinData <- aggregate.data.frame(sMinData,by=list(sMinData$tick), FUN = mean, na.rm = TRUE)
  colnames(aMinData)[4] <- "cost"
  aMinData$type="National Min CO2"

  plotdata <- rbind(aFixData, aVarData, aLoaData, aAucData, aTaxData, aMinData)

  plotname = paste("Agent costs over ", nIterations," iterations", sep="")
  title = paste("Agent costs over ", nIterations, " iterations", sep="")
  x = which( colnames(plotdata)=="tick" )
  y = which( colnames(plotdata)=="cost" )
  group = which( colnames(plotdata)=="type" )
  xlabel = "Tick (year)"
  ylabel = "Costs (EUR)"
  legend = "Cost type"
  n=6

  costplot <- CreateStackedPlot(plotname, title, plotdata, x, y, group, n, xlabel, ylabel, legend)
  return(costplot)
}
