#' Get the column number in powerplant data containing the fullLoadHours variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the fullLoadHours variable
#' @export
pColumnFullLoadHours <- function(headers) {

  cFullLoadHours = as.numeric(which(grepl("fullLoadHours", headers$variables))[1])
  return(cFullLoadHours)
}

#' Get the column number in powerplant data containing the production variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the production variable
#' @export
pColumnProduction <- function(headers) {

  cProduction = as.numeric(which(grepl("production", headers$variables))[1])
  return(cProduction)
}
