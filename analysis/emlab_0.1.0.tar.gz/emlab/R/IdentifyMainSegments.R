#' Get the number of load-duration segments in simulation
#'
#' @param headers column containing headers of the data set
#' @return the number of load-duration segments present in simulation
#' @export
NumberSegments <- function(headers) {

  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)

  temp = paste("price.",vMarkets[1], sep="")
  nSegments = as.numeric(length(which(grepl(temp, headers$variables)))) - 1 ## - 1 to not include average price
  return(nSegments)
}


#' Get the column number in data containing the first load-duration segment's price
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the first load-duration segment's price
#' @export
ColumnPriceSegment <- function(headers) {

  vMarkets = VectorMarkets(headers)

  temp = paste("price.",vMarkets[1], sep="")
  cPriceSegment = as.numeric(which(grepl(temp, headers$variables))[1])
  return(cPriceSegment)
}


#' Get the column number in data containing the first segment's volume used
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the first segment's volume used
#' @export
ColumnVolumeSegment <- function(headers) {

  cVolumeSegment = ColumnPriceSegment(headers) + 1    ## assume reporting price volume price volume
  return(cVolumeSegment)
}


#' Get a vector containing all segments present in simulation
#'
#' @param headers column containing headers of the data
#' @return a vector containing all segments present in simulation
#' @export
VectorSegments <- function(headers) {

  cPriceSegment = ColumnPriceSegment(headers)
  nSegments = NumberSegments(headers)

  vSegments = "Segment 1"

  for (i in 2:nSegments) {
    vSegments <- append(vSegments, paste("Segment",i))
  }

  return(vSegments)
}
