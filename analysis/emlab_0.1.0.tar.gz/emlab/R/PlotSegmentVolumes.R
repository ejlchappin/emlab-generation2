# -----------------------------------------------------------------------------------
# MAIN FUNCTION: Decision logic for plotting electricity volumes
# -----------------------------------------------------------------------------------

#' Plot segmented electricity volume graph(s)
#' @description Example queries:
#' @param data Dataframe of which to take electricity data. Number of markets (1 or 2) is automatically considered.
#' @return Saves plots in workspace automatically.
#' @return Also returns a list of ggplot objects. Can be stored and accessed by user for further ggplot manipulation. In case 'detail' = TRUE, access data like so: PlotObjectList[[x]][[x]].
#' @export
PlotElectricityVolume <- function(data) {

  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)

  # Decision logic on which graphs to create
  # If the dataset contains only one market, plot the volumes for that market
  if(nMarkets == 1) {
    PlotElectricityVolumeOneMarket(data)
  }
  # If the dataset contains two markets, plot the volumes for those markets
  else {
    PlotElectricityVolumeTwoMarket(data)
  }
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 1: One market, no average
# -----------------------------------------------------------------------------------

PlotElectricityVolumeOneMarket <- function(data) {
  message("Plotting two markets' electricity volumes")

  # Working variables
  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)
  cVolumeSegment = ColumnVolumeSegment(headers)
  vSegments = VectorSegments(headers)
  nSegments = NumberSegments(headers)
  cTicks = ColumnTicks(headers)
  cIteration = ColumnIteration(headers)
  nIterations = max(data[cIteration])

  # Select data and add to a new plotdata dataframe
  plotdata <- data.frame(matrix(ncol = 4, nrow = 0))
  colnames(plotdata) <- c("segments","ticks", "volume", "iteration")
  for (i in 1:nSegments) {
    temp <- subset(data, select=c(cTicks, cVolumeSegment + 2*i -2, cIteration))
    temp = cbind(vSegments[i], temp)
    colnames(temp) <- c("segments","ticks", "volume", "iteration")
    plotdata <- rbind(plotdata, temp)
  }

  # Aggregate data
  suppressWarnings(aggregatedsubset <- aggregate.data.frame(plotdata, by=list(plotdata$ticks, plotdata$segments), FUN = mean, na.rm = TRUE))

  # Specify plot information
  plotname = paste("Electricity volumes in ", vMarkets[1] ," over ", nIterations," iterations", sep="")
  title = paste("Electricity volumes in ", vMarkets[1] ," over ", nIterations, " iterations", sep="")
  x = which( colnames(aggregatedsubset)=="ticks" )
  y = which( colnames(aggregatedsubset)=="volume" )
  group = which( colnames(aggregatedsubset)=="Group.2" )
  xlabel = "Tick (year)"
  ylabel = "Electricity Volume (MW)"
  legend = "Segments"

  # Create labels for segments in plot legend
  labels = c("Segment 1")
  for (i in 2:nSegments) {
    labels <- append(labels, paste("Segment",i))
  }

  # Create and save plot
  electricityvolumeplot <- CreateSegmentPlot(plotname, title, aggregatedsubset, x, y, group, nSegments, xlabel, ylabel, legend, labels)
  # Return plot objects so user can modify as needed
  return(electricityvolumeplot)
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 2: Two markets, no average
# -----------------------------------------------------------------------------------

PlotElectricityVolumeTwoMarket <- function(data) {
  message("Plotting two markets' electricity volumes")

  # Working variables
  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)
  cVolumeSegment = ColumnVolumeSegment(headers)
  vSegments = VectorSegments(headers)
  nSegments = NumberSegments(headers)
  cTicks = ColumnTicks(headers)
  cIteration = ColumnIteration(headers)
  nIterations = max(data[cIteration])

  # Create empty list in which to store plots to return to user
  iplots <- list()
  for (i in 1:nMarkets) {
    # Select data and add to a new plotdata dataframe
    plotdata <- data.frame(matrix(ncol = 4, nrow = 0))
    colnames(plotdata) <- c("segments","ticks", "volume", "iteration")
    for (j in 1:nSegments) {
      temp <- subset(data, select=c(cTicks, cVolumeSegment + (41*(i-1)) + 2*j -2, cIteration))
      temp = cbind(vSegments[j], temp)
      colnames(temp) <- c("segments","ticks", "volume", "iteration")
      plotdata <- rbind(plotdata, temp)
    }

    # Aggregate data
    suppressWarnings(aggregatedsubset <- aggregate.data.frame(plotdata, by=list(plotdata$ticks, plotdata$segments), FUN = mean, na.rm = TRUE))

    # Specify plot information
    plotname = paste("Electricity volumes in ", vMarkets[i], " over ", nIterations, " iterations", sep="")
    title = paste("Electricity volumes in ", vMarkets[i], " over ", nIterations, " iterations", sep="")
    x = which( colnames(aggregatedsubset)=="ticks" )
    y = which( colnames(aggregatedsubset)=="volume" )
    group = which( colnames(aggregatedsubset)=="Group.2" )
    xlabel = "Tick (year)"
    ylabel = "Electricity volume (MW)"
    legend = "Segments"

    # Create labels for segments in plot legend
    labels = c("Segment 1")
    for (k in 2:nSegments) {
      labels <- append(labels, paste("Segment",k))
    }

    # Create and save plot
    iplots[[i]] <- CreateSegmentPlot(plotname, title, aggregatedsubset, x, y, group, nSegments, xlabel, ylabel, legend, labels)
  }
  # Return plot objects so user can modify as needed
  return(iplots)
}
