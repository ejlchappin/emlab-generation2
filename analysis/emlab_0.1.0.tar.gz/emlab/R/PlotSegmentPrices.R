# segement colours in plots where averages are included is bugged

# -----------------------------------------------------------------------------------
# MAIN FUNCTION: Decision logic for plotting electricity prices
# -----------------------------------------------------------------------------------

#' Plot segmented electricity price graph(s)
#' @description Example queries:
#' @param data Dataframe of which to take electricity data. Number of markets (1 or 2) is automatically considered.
#' @return Saves plots in workspace automatically.
#' @return Also returns a list of ggplot objects. Can be stored and accessed by user for further ggplot manipulation. In case 'detail' = TRUE, access data like so: PlotObjectList[[x]][[x]].
#' @export
PlotElectricityPrice <- function(data, average) {

  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)

  # Decision logic on which graphs to create

  if(missing(average) | average == FALSE) {
    # If the dataset contains only one market, plot the prices for that market
    if(nMarkets == 1) {
      PlotElectricityPriceOneMarket(data)
    }
    # If the dataset contains two markets, plot the prices for those markets
    else {
      PlotElectricityPriceTwoMarket(data)
    }
  } else {
    # If the dataset contains only one market, plot the prices for that market including average
    if(nMarkets == 1) {
      PlotElectricityPriceOneMarketAverage(data)
    }
    # If the dataset contains two markets, plot the prices for those markets including average
    else {
      PlotElectricityPriceTwoMarketAverage(data)
    }
  }
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 1: One market, no average
# -----------------------------------------------------------------------------------

PlotElectricityPriceOneMarket <- function(data) {
  message("Plotting two markets' electricity prices")

  # Working variables
  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)
  cPriceSegment = ColumnPriceSegment(headers)
  vSegments = VectorSegments(headers)
  nSegments = NumberSegments(headers)
  cTicks = ColumnTicks(headers)
  cIteration = ColumnIteration(headers)
  nIterations = max(data[cIteration])

  # Select data and add to a new plotdata dataframe
  plotdata <- data.frame(matrix(ncol = 4, nrow = 0))
  colnames(plotdata) <- c("segments","ticks", "price", "iteration")
  for (i in 1:nSegments) {
    temp <- subset(data, select=c(cTicks, cPriceSegment + 2*i -2, cIteration))
    temp = cbind(vSegments[i], temp)
    colnames(temp) <- c("segments","ticks", "price", "iteration")
    plotdata <- rbind(plotdata, temp)
  }

  # Aggregate data
  suppressWarnings(aggregatedsubset <- aggregate.data.frame(plotdata, by=list(plotdata$ticks, plotdata$segments), FUN = mean, na.rm = TRUE))

  # Specify plot information
  plotname = paste("Electricity prices in ", vMarkets[1] ," over ", nIterations," iterations", sep="")
  title = paste("Electricity prices in ", vMarkets[1] ," over ", nIterations, " iterations", sep="")
  x = which( colnames(aggregatedsubset)=="ticks" )
  y = which( colnames(aggregatedsubset)=="price" )
  group = which( colnames(aggregatedsubset)=="Group.2" )
  xlabel = "Tick (year)"
  ylabel = "Electricity price (€/MW)"
  legend = "Segments"

  # Create labels for segments in plot legend
  labels = c("Segment 1")
  for (i in 2:nSegments) {
    labels <- append(labels, paste("Segment",i))
  }

  # Create and save plot
  electricitypriceplot <- CreateSegmentPlot(plotname, title, aggregatedsubset, x, y, group, nSegments, xlabel, ylabel, legend, labels)
  # Return plot objects so user can modify as needed
  return(electricitypriceplot)
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 2: Two markets, no average
# -----------------------------------------------------------------------------------

PlotElectricityPriceTwoMarket <- function(data) {
  message("Plotting two markets' electricity prices")

  # Working variables
  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)
  cPriceSegment = ColumnPriceSegment(headers)
  vSegments = VectorSegments(headers)
  nSegments = NumberSegments(headers)
  cTicks = ColumnTicks(headers)
  cIteration = ColumnIteration(headers)
  nIterations = max(data[cIteration])

  # Create empty list in which to store plots to return to user
  iplots <- list()
  for (i in 1:nMarkets) {
    # Select data and add to a new plotdata dataframe
    plotdata <- data.frame(matrix(ncol = 4, nrow = 0))
    colnames(plotdata) <- c("segments","ticks", "price", "iteration")
    for (j in 1:nSegments) {
      temp <- subset(data, select=c(cTicks, cPriceSegment + (41*(i-1)) + 2*j -2, cIteration))
      temp = cbind(vSegments[j], temp)
      colnames(temp) <- c("segments","ticks", "price", "iteration")
      plotdata <- rbind(plotdata, temp)
    }

    # Aggregate data
    suppressWarnings(aggregatedsubset <- aggregate.data.frame(plotdata, by=list(plotdata$ticks, plotdata$segments), FUN = mean, na.rm = TRUE))

    # Specify plot information
    plotname = paste("Electricity prices in ", vMarkets[i], " over ", nIterations, " iterations", sep="")
    title = paste("Electricity prices in ", vMarkets[i], " over ", nIterations, " iterations", sep="")
    x = which( colnames(aggregatedsubset)=="ticks" )
    y = which( colnames(aggregatedsubset)=="price" )
    group = which( colnames(aggregatedsubset)=="Group.2" )
    xlabel = "Tick (year)"
    ylabel = "Electricity price (€/MW)"
    legend = "Segments"

    # Create labels for segments in plot legend
    labels = c("Segment 1")
    for (k in 2:nSegments) {
      labels <- append(labels, paste("Segment",k))
    }

    # Create and save plot
    iplots[[i]] <- CreateSegmentPlot(plotname, title, aggregatedsubset, x, y, group, nSegments, xlabel, ylabel, legend, labels)
  }
  # Return plot objects so user can modify as needed
  return(iplots)
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 3: One market, including average
# -----------------------------------------------------------------------------------

PlotElectricityPriceOneMarketAverage <- function(data) {
  message("Plotting one market's electricity prices")

  # Working variables
  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)
  cPriceSegment = ColumnPriceSegment(headers)
  vSegments = VectorSegments(headers)
  nSegments = NumberSegments(headers)
  cTicks = ColumnTicks(headers)
  cIteration = ColumnIteration(headers)
  nIterations = max(data[cIteration])

  # Select data and add to a new plotdata dataframe
  plotdata <- data.frame(matrix(ncol = 4, nrow = 0))
  colnames(plotdata) <- c("segments","ticks", "price", "iteration")
  for (i in 1:nSegments) {
    temp <- subset(data, select=c(cTicks, cPriceSegment + 2*i -2, cIteration))
    temp = cbind(vSegments[i], temp)
    colnames(temp) <- c("segments","ticks", "price", "iteration")
    plotdata <- rbind(plotdata, temp)
  }

  # Aggregate data
  suppressWarnings(aggregatedsubset <- aggregate.data.frame(plotdata, by=list(plotdata$ticks, plotdata$segments), FUN = mean, na.rm = TRUE))

  # Specify plot information
  plotname = paste("Electricity prices including average in ", vMarkets[1] ," over ", nIterations," iterations", sep="")
  title = paste("Electricity prices including average in ", vMarkets[1] ," over ", nIterations, " iterations", sep="")
  x = which( colnames(aggregatedsubset)=="ticks" )
  y = which( colnames(aggregatedsubset)=="price" )
  group = which( colnames(aggregatedsubset)=="Group.2" )
  xlabel = "Tick (year)"
  ylabel = "Electricity price (€/MW)"
  legend = "Segments"

  # Create labels for segments in plot legend
  labels = c("Segment 1")
  for (i in 2:nSegments) {
    labels <- append(labels, paste("Segment",i))
  }

  # Create and save plot
  electricitypriceplot <- CreateBareSegmentPlot(plotname, title, aggregatedsubset, x, y, group, nSegments, xlabel, ylabel, legend, labels)

  # Add average
  averagedata <- data.frame(matrix(ncol = 4, nrow = 0))
  averagedata <- subset(data, select=c(cTicks, cPriceSegment + 2*nSegments, cIteration))
  averagedata = cbind("segment",averagedata)
  colnames(averagedata) <- c("segment", "ticks", "price", "iteration")

  suppressWarnings(aggregatedaverage <- aggregate.data.frame(averagedata, by=list(averagedata$ticks), FUN = mean, na.rm = TRUE))

  electricitypriceplot <- electricitypriceplot +
    geom_line(data=aggregatedaverage, aes(x=aggregatedaverage$ticks, y=aggregatedaverage$price, colour="Average"))
  ggsave(paste(plotname, ".png",sep=""), width = 8, height = 5)
  message(paste("Plot '", plotname, "' added to your working directory", sep=""))

  # Return plot objects so user can modify as needed
  return(electricitypriceplot)
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 4: Two markets, including average
# -----------------------------------------------------------------------------------

PlotElectricityPriceTwoMarketAverage <- function(data) {
    message("Plotting two markets' electricity prices")

    # Working variables
    headers = GetHeaders(data)
    nMarkets = NumberMarkets(headers)
    vMarkets = VectorMarkets(headers)
    cPriceSegment = ColumnPriceSegment(headers)
    vSegments = VectorSegments(headers)
    nSegments = NumberSegments(headers)
    cTicks = ColumnTicks(headers)
    cIteration = ColumnIteration(headers)
    nIterations = max(data[cIteration])

    # Create empty list in which to store plots to return to user
    iplots <- list()
    for (i in 1:nMarkets) {
      # Select data and add to a new plotdata dataframe
      plotdata <- data.frame(matrix(ncol = 4, nrow = 0))
      colnames(plotdata) <- c("segments","ticks", "price", "iteration")
      for (j in 1:nSegments) {
        temp <- subset(data, select=c(cTicks, cPriceSegment + (41*(i-1)) + 2*j -2, cIteration))
        temp = cbind(vSegments[j], temp)
        colnames(temp) <- c("segments","ticks", "price", "iteration")
        plotdata <- rbind(plotdata, temp)
      }

      # Aggregate data
      suppressWarnings(aggregatedsubset <- aggregate.data.frame(plotdata, by=list(plotdata$ticks, plotdata$segments), FUN = mean, na.rm = TRUE))

      # Specify plot information
      plotname = paste("Electricity prices including averages in ", vMarkets[i], " over ", nIterations, " iterations", sep="")
      title = paste("Electricity prices including averages in ", vMarkets[i], " over ", nIterations, " iterations", sep="")
      x = which( colnames(aggregatedsubset)=="ticks" )
      y = which( colnames(aggregatedsubset)=="price" )
      group = which( colnames(aggregatedsubset)=="Group.2" )
      xlabel = "Tick (year)"
      ylabel = "Electricity price (€/MW)"
      legend = "Segments"

      # Create labels for segments in plot legend
      labels = c("Segment 1")
      for (k in 2:nSegments) {
        labels <- append(labels, paste("Segment",k))
      }

      # Create and save plot
      electricitypriceplot <- CreateBareSegmentPlot(plotname, title, aggregatedsubset, x, y, group, nSegments, xlabel, ylabel, legend, labels)

      # Add average
      averagedata <- data.frame(matrix(ncol = 4, nrow = 0))
      averagedata <- subset(data, select=c(cTicks, (41*(i-1) + cPriceSegment + 2*nSegments), cIteration))
      averagedata = cbind("segment",averagedata)
      colnames(averagedata) <- c("segment", "ticks", "price", "iteration")

      suppressWarnings(aggregatedaverage <- aggregate.data.frame(averagedata, by=list(averagedata$ticks), FUN = mean, na.rm = TRUE))

      electricitypriceplot <- electricitypriceplot +
        geom_line(data=aggregatedaverage, aes(x=aggregatedaverage$ticks, y=aggregatedaverage$price, colour="Average"))

      ggsave(paste(plotname, ".png",sep=""), width = 8, height = 5)
      message(paste("Plot '", plotname, "' added to your working directory", sep=""))

      iplots[[i]] <- electricitypriceplot

    }
    # Return plot objects so user can modify as needed
    return(iplots)
  }
