#' Read in data from main file
#'
#' @param filename of file to read
#' @param directory in which we are working
#' @return Ordered and clean dataset
#' @export
ReadMainData <- function(filename, directory) {

  options(StringsAsFactors = FALSE)
  setwd(directory)
  data = read.table(filename, head=TRUE,  sep=';', comment.char = "")
  data = data[with(data, order(iteration, tick)), ]

  return(data)
}

#' Read in data from powerplantfile
#'
#' @param filename of file to read
#' @param directory in which we are working
#' @return Ordered and clean dataset
#' @export
ReadPowerplantData <- function(filename, directory) {

  options(StringsAsFactors = FALSE)
  setwd(directory)
  data = read.table(filename, head=TRUE,  sep=';', comment.char = "")
  data = data[with(data, order(iteration, tick)), ]

  return(data)
}

#' Read headers from data
#'
#' @param data data table to read from
#' @return a column of header strings
#' @export
GetHeaders <- function(data) {

  headers = data.frame(colnames(data))
  colnames(headers)[1] <- "variables"

  return(headers)
}

#' Aggregate data containing multiple runs into one run containing mean values
#'
#' @param data data table to read from
#' @return aggregated (on mean) data table
#' @export
AggregateDataMean <- function(data) {

  headers = GetHeaders(data)
  cTicks = ColumnTicks(headers)
  data$tick
  data[2]
  meandata = aggregate.data.frame(data, by=list(data$tick), FUN = mean, na.rm = TRUE)

  return(meandata)
}
