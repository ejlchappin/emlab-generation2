#' Get the number of agents present in simulation
#'
#' @param headers column containing headers of the data set
#' @return the number of agents present in simulation
#' @export
NumberAgents <- function(headers) {

  nAgents = as.numeric(length(which(grepl("cash.", headers$variables)))) - 7 # -7 cashflows... wonky but works
  return(nAgents)
}


#' Get the column number in data containing the first agent's cash balance
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the first agent's cash balance
#' @export
ColumnCashAgent <- function(headers) {

  cPipelineCapacity = ColumnPipelineCapacity(headers)
  nMarkets = NumberMarkets(headers)
  cCashAgent = cPipelineCapacity+nMarkets
  return(cCashAgent)
}


#' Get a vector containing all agents present in simulation
#'
#' @param headers column containing headers of the data set
#' @return a vector containing all agents present in simulation
#' @export
VectorAgents <- function(headers) {

  cCashAgent = ColumnCashAgent(headers)
  nAgents = NumberAgents(headers)

  vAgents = gsub("\\."," ",gsub("cash.", "", headers[cCashAgent,]))
  for (i in 2:nAgents-1) {
    vAgents <- append(vAgents, gsub("\\."," ",gsub("cash.", "", headers[cCashAgent+i,])))
  }

  return(vAgents)
}
