#' Get the number of substances (fuels) present in simulation
#'
#' @param headers column containing headers of the data set
#' @return the number of substances (fuels) present in simulation
#' @export
NumberSubstances <- function(headers) {

  cCashAgents = ColumnCashAgent(headers)
  nAgents = NumberAgents(headers)
  cPriceCO2 = ColumnPriceCO2(headers)

  nSubstances = (cPriceCO2 - cCashAgents - nAgents) / 2
  return(nSubstances)
}


#' Get the column number in data containing the first substance's price
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the first substance's price
#' @export
ColumnPriceSubstance <- function(headers) {

  cCashAgents = ColumnCashAgent(headers)
  nAgents = NumberAgents(headers)

  cPriceSubstance = cCashAgents + nAgents
  return(cPriceSubstance)
}


#' Get the column number in data containing the first substance's volume used
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the first substance's volume used
#' @export
ColumnVolumeSubstance <- function(headers) {

  cPriceSubstance = ColumnPriceSubstance(headers)
  cVolumeSubstance = cPriceSubstance + 1
  return(cVolumeSubstance)
}


#' Get a vector containing all substances present in simulation
#'
#' @param headers column containing headers of the data
#' @return a vector containing all substances present in simulation
#' @export
VectorSubstances <- function(headers) {

  cPriceSubstance = ColumnPriceSubstance(headers)
  nSubstances = NumberSubstances(headers)

  vSubstances = gsub("\\.","",gsub("price.", "", headers[cPriceSubstance,]))

  for (i in 2:nSubstances-1) {
    vSubstances <- append(vSubstances, gsub("\\.","",gsub("price.", "", headers[cPriceSubstance+2*i,])))
  }

  return(vSubstances)
}
