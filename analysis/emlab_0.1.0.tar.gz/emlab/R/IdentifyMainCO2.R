#' Get the column number in data containing the price of CO2
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the price of CO2
#' @export
ColumnPriceCO2 <- function(headers) {

  cPriceCO2 = as.numeric(which(grepl("price.co2", headers$variables))[1])
  return(cPriceCO2)
}


#' Get the column number in data containing the volume of traded CO2 credits
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the volume of traded CO2 credits
#' @export
ColumnVolumeRightsTraded <- function(headers) {

  cVolumeRightsTraded = as.numeric(which(grepl("volume.traded.co2.emissions", headers$variables))[1])
  return(cVolumeRightsTraded)
}

#' Get the column number in data containing the emission of CO2
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the emission of CO2
#' @export
ColumnEmissionsCO2 <- function(headers) {

  cEmissionsCO2 = as.numeric(which(grepl("volume.total.co2.emissions", headers$variables))[1])
  return(cEmissionsCO2)
}
