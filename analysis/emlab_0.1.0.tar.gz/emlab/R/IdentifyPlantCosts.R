#' Get the column number in powerplant data containing the commodityCosts variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the commodityCosts variable
#' @export
pColumnCommodityCosts <- function(headers) {

  cCommodityCosts = as.numeric(which(grepl("commodityCosts", headers$variables))[1])
  return(cCommodityCosts)
}

#' Get the column number in powerplant data containing the co2Costs variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the co2Costs variable
#' @export
pColumnCO2Costs <- function(headers) {

  cCO2Costs = as.numeric(which(grepl("co2Costs", headers$variables))[1])
  return(cCO2Costs)
}

#' Get the column number in powerplant data containing the variableCosts variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the variableCosts variable
#' @export
pColumnVariableCosts <- function(headers) {

  cVariableCosts = as.numeric(which(grepl("variableCosts", headers$variables))[1])
  return(cVariableCosts)
}

#' Get the column number in powerplant data containing the fixedCosts variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the fixedCosts variable
#' @export
pColumnFixedCosts <- function(headers) {

  cFixedCosts = as.numeric(which(grepl("fixedCosts", headers$variables))[1])
  return(cFixedCosts)
}
