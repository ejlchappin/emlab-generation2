#' Plot duration of the simulation of a run in a ribbon plot
#' @description Example query: PlotDuration(data)
#' @param data Dataframe of which to take duration data.
#' @return Saves plots in workspace automatically.
#' @return Also a ggplot object. Can be stored and accessed by user for further ggplot manipulation.
#' @export
PlotNrPowerPlants <- function(data) {

  headers = GetHeaders(data)
  cIter = ColumnIteration(headers)
  cTick = ColumnTicks(headers)
  cNrPowerPlants = ColumnNrPowerPlants(headers)
  sData <- data[,c(cIter,cTick,cNrPowerPlants)]
  nMarket <- NumberMarkets(headers)
  vMarket <- VectorMarkets(headers)

  # Retrieve values for min, max and average and add them to plotting dataframe 'pData'
  min <- aggregate.data.frame(sData,by=list(sData$tick), FUN = min, na.rm = TRUE)
  max <- aggregate.data.frame(sData,by=list(sData$tick), FUN = max, na.rm = TRUE)
  pData <- aggregate.data.frame(sData,by=list(sData$tick), FUN = mean, na.rm = TRUE)
  pData["min"] <- min$nr.of.powerplants
  pData["max"] <- max$nr.of.powerplants

  if (nMarket == 1) {
    plotname = paste("Number of powerplants in ", vMarket[1], sep="")
    title = paste("Number of powerplants in ", vMarket[1], sep="")
  } else {
    plotname = paste("Number of powerplants in ", vMarket[1], " and ", vMarket[2], sep="")
    title = paste("Number of powerplants in ", vMarket[1], " and ", vMarket[2], sep="")
  }

  xlabel = "Tick (year)"
  ylabel = "Powerplants (#)"

  # Create plot
  plotobject <- ggplot(pData, aes(x=tick, y=nr.of.powerplants, ymin=min, ymax=max)) +
    geom_ribbon(fill="dodgerblue", alpha=.6) +
    geom_line(colour="black", size=1) +
    labs(title =title, y=ylabel, x=xlabel) +
    theme_minimal()

  ggsave(paste(plotname, ".png",sep=""), plot=plotobject, width=8, height=5)
  message(paste("Plot '", plotname, "' added to your working directory", sep=""))
  return(plotobject)

}
