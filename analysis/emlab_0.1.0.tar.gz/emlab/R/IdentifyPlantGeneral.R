#' Get the column number in powerplant data containing the iteration variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the iteration variable
#' @export
pColumnIteration <- function(headers) {

  cIteration = as.numeric(which(grepl("iteration", headers$variables))[1])
  return(cIteration)
}

#' Get the column number in powerplant data containing the tick variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the tick variable
#' @export
pColumnTick <- function(headers) {

  cTick = as.numeric(which(grepl("tick", headers$variables))[1])
  return(cTick)
}

#' Get the column number in powerplant data containing the name variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the name variable
#' @export
pColumnName <- function(headers) {

  cName = as.numeric(which(grepl("name", headers$variables))[1])
  return(cName)
}
