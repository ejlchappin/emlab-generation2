# -----------------------------------------------------------------------------------
# MAIN FUNCTION: Decision logic for capacity plotting
# -----------------------------------------------------------------------------------

#' Plot operational generation capacity graph(s) by technology
#' @description Example queries: PlotCapacity(data, detail = FALSE), PlotCapacity(data, TRUE), PlotObjectList = PlotCapacity(data, FALSE)
#' @param data Dataframe of which to take capacity data. Number of markets (1 or 2) is automatically considered.
#' @param detail A boolean. If TRUE, the function plots capacity in iterations seperately. If FALSE, it plots averages over all iterations.
#' @return Saves plots in workspace automatically.
#' @return Also returns a list of ggplot objects. Can be stored and accessed by user for further ggplot manipulation. In case 'detail' = TRUE, access data like so: PlotObjectList[[x]][[x]].
#' @export
PlotCapacity <- function(data, detail) {

  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)

  # Decision logic on which graphs to create

  # If no detail is requested, do the following to get iteration averaged plots
  if(missing(detail) | detail == FALSE) {
    # If the dataset contains only one market, plot the averaged plant capacities for that market
    if(nMarkets == 1) {
      PlotCapacityOneMarketAverage(data)
    }
    # If the dataset contains two markets, plot the averaged plant capacities for individual markets, as well as for combined capacity
    else {
      PlotCapacityTwoMarketAverage(data)
    }
  }
  # If detail is requested, do the following to get iteration specific plots
  else {
    if(nMarkets == 1) {
      # If the dataset contains only one market, make a plot for all iterations for that market
      PlotCapacityOneMarketIterations(data)
    }
    # If the dataset contains two markets, plot the iterations for individual markets, as well as for combined capacity
    else {
      PlotCapacityTwoMarketIterations(data)
    }
  }
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 1: One market, averages
# -----------------------------------------------------------------------------------

#' Helper function, please use PlotCapacity
PlotCapacityOneMarketAverage <- function(data) {
  message("Plotting one market's average")

  # Working variables
  headers = GetHeaders(data)
  vMarkets = VectorMarkets(headers)
  nTechs = NumberTechnologies(headers)
  vTechs = VectorTechnologies(headers)
  cTicks = ColumnTicks(headers)
  cCapacityTech = ColumnCapacityTech(headers)
  cIteration = ColumnIteration(headers)
  nIterations = max(data[cIteration])

  # Select data and add to a new plotdata dataframe
  plotdata <- data.frame(matrix(ncol = 4, nrow = 0))
  colnames(plotdata) <- c("technology ","ticks", "capacity", "iteration")
  for (i in nTechs:1) {
    temp <- subset(data, select=c(cTicks, cCapacityTech-1 + i, cIteration))
    temp = cbind(vTechs[i], temp)
    colnames(temp) <- c("technology","ticks", "capacity", "iteration")
    plotdata <- rbind(plotdata, temp)
  }

  # Aggregate data
  suppressWarnings(aggregatedsubset <- aggregate.data.frame(plotdata, by=list(plotdata$ticks, plotdata$technology), FUN = mean, na.rm = TRUE))

  # Specify plot information
  plotname = paste("Average generation capacity over ", nIterations," iterations", sep="")
  title = paste("Average operational generation capacity (over ", nIterations, " iterations)", sep="")
  x = which( colnames(aggregatedsubset)=="ticks" )
  y = which( colnames(aggregatedsubset)=="capacity" )
  group = which( colnames(aggregatedsubset)=="Group.2" )
  xlabel = "Tick (year)"
  ylabel = "Generation capacity (MW)"
  legend = "Technology"

  # Create and save plot
  capacityplot <- CreateStackedPlot(plotname, title, aggregatedsubset, x, y, group, nTechs, xlabel, ylabel, legend)
  # Return plot objects so user can modify as needed
  return(capacityplot)
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 2: Two markets, averages
# -----------------------------------------------------------------------------------

#' Helper function, please use PlotCapacity
PlotCapacityTwoMarketAverage <- function(data) {
  message("Plotting two markets' average")

  # Working variables
  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)
  nTechs = NumberTechnologies(headers)
  vTechs = VectorTechnologies(headers)
  cTicks = ColumnTicks(headers)
  cCapacityTech = ColumnCapacityTech(headers)
  cIteration = ColumnIteration(headers)
  nIterations = max(data[cIteration])

  # Select data and add to a new plotdata dataframe
  plotdata <- data.frame(matrix(ncol = 5, nrow = 0))
  colnames(plotdata) <- c("technology ","ticks", "capacity1", "capacity2", "iteration")

  for (i in nTechs:1) {
    # Subset data for each tech in a temp dataframe and bind it to plotdata
    temp <- subset(data, select=c(cTicks, cCapacityTech-1 + i, cCapacityTech-1+nTechs + i, cIteration))
    temp = cbind(vTechs[i], temp)
    colnames(temp) <- c("technology","ticks", "capacity1", "capacity2", "iteration")
    plotdata <- rbind(plotdata, temp)
  }

  # Aggregate data to create averages, supress warnings for user experience
  suppressWarnings(aggregatedsubset <- aggregate.data.frame(plotdata, by=list(plotdata$ticks, plotdata$technology), FUN = mean, na.rm = TRUE))

  # Create column containing totals
  aggregatedsubset["total"] <- NA
  aggregatedsubset$total <- aggregatedsubset$capacity1 + aggregatedsubset$capacity2

  # Specify plot information for combined markets plot
  plotname = paste("Average generation capacity over ", nIterations," iterations in both markets", sep="")
  title = paste("Average operational generation capacity (over ", nIterations, " iterations)", sep="")
  x = which( colnames(aggregatedsubset)=="ticks" )
  y = which( colnames(aggregatedsubset)=="total" )
  group = which( colnames(aggregatedsubset)=="Group.2" )
  xlabel = "Tick (year)"
  ylabel = "Generation capacity (MW)"
  legend = "Technology"

  # Create and save combined markets plot
  capacityplotav <- CreateStackedPlot(plotname, title, aggregatedsubset, x, y, group, nTechs, xlabel, ylabel, legend)

  # Specify, create and save market 1 plot
  plotname1 = paste("Average generation capacity over ", nIterations," iterations in ", vMarkets[1], sep="")
  title1 = paste("Average operational generation capacity in ", vMarkets[1] ," (over ", nIterations, " iterations)", sep="")
  y1 = which( colnames(aggregatedsubset)=="capacity1")
  capacityplot1 <- CreateStackedPlot(plotname1, title1, aggregatedsubset, x, y1, group, nTechs, xlabel, ylabel, legend)

  # Specify, create and save market 2 plot
  plotname2 = paste("Average generation capacity over ", nIterations," iterations in ", vMarkets[2], sep="")
  title2 = paste("Average operational generation capacity in ", vMarkets[2] ," (over ", nIterations, " iterations)", sep="")
  y2 = which( colnames(aggregatedsubset)=="capacity2")
  capacityplot2 <- CreateStackedPlot(plotname2, title2, aggregatedsubset, x, y2, group, nTechs, xlabel, ylabel, legend)

  # Return plot objects so user can modify as needed
  return(list(capacityplotav, capacityplot1, capacityplot2))
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 3: One market, iterations
# -----------------------------------------------------------------------------------

#' Helper function, please use PlotCapacity
PlotCapacityOneMarketIterations <- function(data) {
  message("Plotting one market's iterations")

  # Working variables
  headers = GetHeaders(data)
  nTechs = NumberTechnologies(headers)
  vTechs = VectorTechnologies(headers)
  cTicks = ColumnTicks(headers)
  cCapacityTech = ColumnCapacityTech(headers)
  cIterations = ColumnIteration(headers)
  nIterations = max(data[cIterations])

  # Create empty list in which to store plots to return to user
  icapacityplot <- list()
  for (i in 1:nIterations) {

    iterationdata =  data[data[cIterations] == i,]

    # Create (empty) ggplot-specific data structure
    plotdata <- data.frame(matrix(ncol = 4, nrow = 0))
    colnames(plotdata) <- c("technology ","ticks", "capacity", "iteration")

    # Select data and add to plotdata
    for (j in nTechs:1) {
      temp <- subset(iterationdata, select=c(cTicks, cCapacityTech-1 + j, cIterations))
      temp = cbind(vTechs[j], temp)
      colnames(temp) <- c("technology","ticks", "capacity", "iteration")
      plotdata <- rbind(plotdata, temp)
    }

    # Specify plot information
    plotname = paste("Generation capacity in iteration ", i, sep="")
    title = paste("Operational generation capacity in iteration ", i, sep="")
    x = which( colnames(plotdata)=="ticks" )
    y = which( colnames(plotdata)=="capacity" )
    group = which( colnames(plotdata)=="technology" )
    xlabel = "Tick (year)"
    ylabel = "Generation capacity (MW)"
    legend = "Technology"

    # Create and save plot
    icapacityplot[[i]] <- CreateStackedPlot(plotname, title, plotdata, x, y, group, nTechs, xlabel, ylabel, legend)
  }

  # Return plot objects so user can modify as needed
  return(icapacityplot)
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 4: Two markets, iterations
# -----------------------------------------------------------------------------------

#' Helper function, please use PlotCapacity
PlotCapacityTwoMarketIterations <- function(data) {
  message("Plotting two markets' iterations")

  # Working variables
  headers = GetHeaders(data)
  nTechs = NumberTechnologies(headers)
  vTechs = VectorTechnologies(headers)
  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)
  cTicks = ColumnTicks(headers)
  cCapacityTech = ColumnCapacityTech(headers)
  cIterations = ColumnIteration(headers)
  nIterations = max(data[cIterations])

  # Create empty lists in which to store plots to return to user
  icapacityplotav <- list()
  icapacityplot1 <- list()
  icapacityplot2 <- list()

  # Create the plots for every iteration
  for (i in 1:nIterations) {

    iterationdata =  data[data[cIterations] == i,]

    # Create (empty) ggplot-specific data structure
    plotdata <- data.frame(matrix(ncol = 5, nrow = 0))
    colnames(plotdata) <- c("technology ","ticks", "capacity1", "capacity2", "iteration")

    # Select data and add to plotdata
    for (j in nTechs:1) {
      temp <- subset(iterationdata, select=c(cTicks, cCapacityTech-1 + j, cCapacityTech-1+nTechs + j, cIterations))
      temp = cbind(vTechs[j], temp)
      colnames(temp) <- c("technology","ticks", "capacity1", "capacity2", "iteration")
      plotdata <- rbind(plotdata, temp)
    }

    # Create column containing totals
    plotdata["total"] <- NA
    plotdata$total <- plotdata$capacity1 + plotdata$capacity2

    # Specify plot information
    plotname = paste("Generation capacity in both markets in iteration ", i, sep="")
    title = paste("Operational generation capacity in both markets in iteration ", i, sep="")
    x = which(colnames(plotdata)=="ticks" )
    y = which(colnames(plotdata)=="total" )
    group = which(colnames(plotdata)=="technology" )
    xlabel = "Tick (year)"
    ylabel = "Generation capacity (MW)"
    legend = "Technology"

    # Create and save combined markets plot
    capacityplotav <- CreateStackedPlot(plotname, title, plotdata, x, y, group, nTechs, xlabel, ylabel, legend)

    # Specify, create and save market 1 plot
    plotname1 = paste("Generation capacity in ", vMarkets[1], " in iteration ", i, sep="")
    title1 = paste("Operational generation capacity in ", vMarkets[1] ," in iteration ", i, sep="")
    y1 = which( colnames(plotdata)=="capacity1")
    capacityplot1 <- CreateStackedPlot(plotname1, title1, plotdata, x, y1, group, nTechs, xlabel, ylabel, legend)

    # Specify, create and save market 2 plot
    plotname2 = paste("Generation capacity in ", vMarkets[2], " in iteration ", i, sep="")
    title2 = paste("Operational generation capacity in ", vMarkets[2] ," in iteration ", i, sep="")
    y2 = which( colnames(plotdata)=="capacity2")
    capacityplot2 <- CreateStackedPlot(plotname2, title2, plotdata, x, y2, group, nTechs, xlabel, ylabel, legend)

    # Add plots to list to return to user
    icapacityplotav[[i]] <- capacityplotav
    icapacityplot1[[i]] <- capacityplot1
    icapacityplot2[[i]] <- capacityplot2
  }

  # Return plot objects so user can modify as needed
  return(list(icapacityplotav, icapacityplot1, icapacityplot2))
}
