#' Get the column number in powerplant data containing the spotMarketRevenue variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the spotMarketRevenue variable
#' @export
pColumnSpotRevenue <- function(headers) {

  cSpotRevenue = as.numeric(which(grepl("spotMarketRevenue", headers$variables))[1])
  return(cSpotRevenue)
}

#' Get the column number in powerplant data containing the longTermMarketRevenue variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the longTermMarketRevenue variable
#' @export
pColumnLongTermRevenue <- function(headers) {

  cLongTermRevenue = as.numeric(which(grepl("longTermMarketRevenue", headers$variables))[1])
  return(cLongTermRevenue)
}

#' Get the column number in powerplant data containing the capacityMarketRevenue variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the capacityMarketRevenue variable
#' @export
pColumnCapacityMarketRevenue <- function(headers) {

  cCapacityMarketRevenue = as.numeric(which(grepl("capacityMarketRevenue", headers$variables))[1])
  return(cCapacityMarketRevenue)
}

#' Get the column number in powerplant data containing the strategicReserveRevenue variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the strategicReserveRevenue variable
#' @export
pColumnStrategicReserveRevenue <- function(headers) {

  cStrategicReserveRevenue = as.numeric(which(grepl("strategicReserveRevenue", headers$variables))[1])
  return(cStrategicReserveRevenue)
}

#' Get the column number in powerplant data containing the co2HedgingRevenue variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the co2HedgingRevenue variable
#' @export
pColumnCO2HedgingRevenue <- function(headers) {

  cCO2HedgingRevenue = as.numeric(which(grepl("co2HedgingRevenue", headers$variables))[1])
  return(cCO2HedgingRevenue)
}

#' Get the column number in powerplant data containing the overallRevenue variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the overallRevenue variable
#' @export
pColumnOverallRevenue <- function(headers) {

  cOverallRevenue = as.numeric(which(grepl("overallRevenue", headers$variables))[1])
  return(cOverallRevenue)
}

