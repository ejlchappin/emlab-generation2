#' Get the column number in data containing the operational capacity variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the operational capacity variable
#' @export
ColumnCapacityPlants <- function(headers) {

  cCapacityPlants = as.numeric(which(grepl("operational.capacity.powerplants", headers$variables))[1])
  return(cCapacityPlants)
}


#' Get the column number in data containing the first specific technology's capacity
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the first specific technology's capacity
#' @export
ColumnCapacityTech <- function(headers) {

  cCapacityTech = ColumnCapacityPlants(headers) + 1
  return(cCapacityTech)
}


#' Get the number of specific generation technologies present in simulation
#'
#' @param headers column containing headers of the data set
#' @return the number of specific generation technologies present in simulation
#' @export
NumberTechnologies <- function(headers) {

  nMarkets = NumberMarkets(headers)
  nTechs = ((as.numeric(length(which(grepl("operational.capacity", headers$variables))))) - 1) / nMarkets
  return(nTechs)
}


#' Get a vector containing all specific generation technologies present in simulation
#'
#' @param headers column containing headers of the data
#' @return a vector containing all specific generation technologies present in simulation
#' @export
VectorTechnologies <- function(headers) {

  cCapacityTech = ColumnCapacityTech(headers)
  nTechs = NumberTechnologies(headers)
  vMarkets = VectorMarkets(headers)

  vTechs = gsub("\\.","",gsub(vMarkets[1],"",gsub("operational.capacity", "", headers[cCapacityTech,])))

  for (i in 2:nTechs-1) {
    vTechs <- append(vTechs, gsub("\\.","",gsub(vMarkets[1],"",gsub("operational.capacity", "", headers[cCapacityTech+i,]))))
  }

  return(vTechs)
}
