#' Get the column number in data containing total cash flow on spot market
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing total cash flow on spot market
#' @export
ColumnFlowSpot <- function(headers) {

  cFlowSpot = as.numeric(which(grepl("cashflow.ELECTRICITYSPOT", headers$variables))[1])
  return(cFlowSpot)
}


#' Get the column number in data containing total cash flow on commodity market
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing total cash flow on commodity market
#' @export
ColumnFlowCommodity <- function(headers) {

  cFlowCommodity = as.numeric(which(grepl("cashflow.COMMODITY", headers$variables))[1])
  return(cFlowCommodity)
}


#' Get the column number in data containing total cash flow for fixed costs
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing total cash flow for fixed costs
#' @export
ColumnFlowFixedCost <- function(headers) {

  cFlowFixedCost = as.numeric(which(grepl("cashflow.FIXEDOMCOST", headers$variables))[1])
  return(cFlowFixedCost)
}


#' Get the column number in data containing total cash flow for loans
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing total cash flow for loans
#' @export
ColumnFlowLoan <- function(headers) {

  cFlowLoan = as.numeric(which(grepl("cashflow.LOAN", headers$variables))[1])
  return(cFlowLoan)
}


#' Get the column number in data containing total cash flow from CO2 auction
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing total cash flow from CO2 auction
#' @export
ColumnFlowCO2Auction <- function(headers) {

  cFlowCO2Auction = as.numeric(which(grepl("cashflow.CO2AUCTION", headers$variables))[1])
  return(cFlowCO2Auction)
}


#' Get the column number in data containing total cash flow from CO2 tax
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing total cash flow from CO2 tax
#' @export
ColumnFlowCO2Tax <- function(headers) {

  cFlowCO2Tax = as.numeric(which(grepl("cashflow.CO2TAX", headers$variables))[1])
  return(cFlowCO2Tax)
}


#' Get the column number in data containing total cash flow from national minimum CO2 tax revenue
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing total cash flow from national minimum CO2 tax revenue
#' @export
ColumnFlownNationalMinCO2 <- function(headers) {

  cFlownNationalMinCO2 = as.numeric(which(grepl("cashflow.NATIONALMINCO2", headers$variables))[1])
  return(cFlownNationalMinCO2)
}
