#' Get the number of markets present in simulation
#'
#' @param headers column containing headers of the data set
#' @return the number of markets present in simulation
#' @export
NumberMarkets <- function(headers) {

  nMarkets = as.numeric(length(which(grepl("pipeline.capacity", headers$variables))))
  return(nMarkets)
}


#' Get the column number in data containing the first market
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the first market
#' @export
ColumnCapacityMarket <- function(headers) {

  cCapacityMarkets = ColumnPipelineCapacity(headers) - NumberMarkets(headers)
  #cCapacityMarkets = as.numeric(which(grepl("capacity.market", headers$variables))[1])
  return(cCapacityMarkets)
}


#' Get the column number in data containing the first market's pipeline capacity
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the first market's pipeline capacity
#' @export
ColumnPipelineCapacity <- function(headers) {

  cPipelineCapacity = as.numeric(which(grepl("pipeline.capacity", headers$variables))[1])
  return(cPipelineCapacity)
}


#' Get a vector containing all markets present in simulation
#'
#' @param headers column containing headers of the data set
#' @return a vector containing all markets present in simulation
#' @export
VectorMarkets <- function(headers) {

  cCapacityMarkets = ColumnCapacityMarket(headers)
  nMarkets = NumberMarkets(headers)

  temp <- strsplit(as.character(headers[cCapacityMarkets,1]),split='\\.')
  vMarkets = temp[[1]][2]

  for (i in 2:nMarkets) {
    temp2 <- strsplit(as.character(headers[cCapacityMarkets+i-1,1]),split='\\.')
    vMarkets <- append(vMarkets, temp2[[1]][2])
  }

  return(vMarkets)
}
