# -----------------------------------------------------------------------------------
# MAIN FUNCTION: Decision logic for pipeline capacity plotting
# -----------------------------------------------------------------------------------

#' Plot generation capacity being built over a simulation in a ribbon plot
#' @description Example query: PlotPipelineCapacity(data)
#' @param data Dataframe of which to take pipeline capacity data.
#' @return Saves plots in workspace automatically.
#' @return Also a ggplot object. Can be stored and accessed by user for further ggplot manipulation.
#' @export
PlotPipelineCapacity <- function(data) {

  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)

  if(nMarkets == 1) {
    PlotPipelineCapacityOneMarket(data, headers)
  }  else {
    PlotPipelineCapacityTwoMarket(data, headers)
  }
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 1: One market
# -----------------------------------------------------------------------------------

PlotPipelineCapacityOneMarket <- function(data, headers) {

  cIter = ColumnIteration(headers)
  cTick = ColumnTicks(headers)
  cPipelineCapacity = ColumnPipelineCapacity(headers)
  vMarket = VectorMarkets(headers)
  sData <- data[,c(cIter,cTick, cPipelineCapacity)]

  # Retrieve values for min, max and average and add them to dataframe 'pData'
  min <- aggregate.data.frame(sData,by=list(sData$tick), FUN = min, na.rm = TRUE)
  max <- aggregate.data.frame(sData,by=list(sData$tick), FUN = max, na.rm = TRUE)
  pData <- aggregate.data.frame(sData,by=list(sData$tick), FUN = mean, na.rm = TRUE)
  pData["min"] <- min[4]
  pData["max"] <- max[4]

  plotname = paste("Generation capacity in ", vMarket[1], " pipeline", sep="")
  title = paste("Generation capacity in ", vMarket[1], " pipeline (planned or being built)", sep="")
  xlabel = "Tick (year)"
  ylabel = "Generation Capacity (MW)"

  # Create plot
  plotobject <- ggplot(pData, aes(x=tick, y=pData[[4]], ymin=min, ymax=max)) +
    geom_ribbon(fill="dodgerblue", alpha=.6) +
    geom_line(colour="black", size=1) +
    labs(title =title, y=ylabel, x=xlabel) +
    theme_minimal()

  ggsave(paste(plotname, ".png",sep=""), plot=plotobject, width=8, height=5)
  message(paste("Plot '", plotname, "' added to your working directory", sep=""))

  return(plotobject)
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 2: Two markets
# -----------------------------------------------------------------------------------

PlotPipelineCapacityTwoMarket <- function(data, headers) {

  cIter = ColumnIteration(headers)
  cTick = ColumnTicks(headers)
  cPipelineCapacity = ColumnPipelineCapacity(headers)
  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)

  for (i in 1:nMarkets) {
    sData <- data[,c(cIter,cTick, (cPipelineCapacity-1+i))]

    # Retrieve values for min, max and average and add them to dataframe 'pData'
    min <- aggregate.data.frame(sData,by=list(sData$tick), FUN = min, na.rm = TRUE)
    max <- aggregate.data.frame(sData,by=list(sData$tick), FUN = max, na.rm = TRUE)
    pData <- aggregate.data.frame(sData,by=list(sData$tick), FUN = mean, na.rm = TRUE)
    pData["min"] <- min[4]
    pData["max"] <- max[4]

    plotname = paste("Generation capacity in ", vMarkets[i], " pipeline ", sep="")
    title = paste("Generation capacity in ", vMarkets[i], "pipeline (planned or being built)", sep="")
    xlabel = "Tick (year)"
    ylabel = "Generation Capacity (MW)"

    # Create plot
    plotobject <- ggplot(pData, aes(x=tick, y=pData[[4]], ymin=min, ymax=max)) +
      geom_ribbon(fill="dodgerblue", alpha=.6) +
      geom_line(colour="black", size=1) +
      labs(title =title, y=ylabel, x=xlabel) +
      theme_minimal()

    ggsave(paste(plotname, ".png",sep=""), plot=plotobject, width=8, height=5)
    message(paste("Plot '", plotname, "' added to your working directory", sep=""))
  }
  return(plotobject)
}



