#' Get the column number in powerplant data containing the technology variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the technology variable
#' @export
pColumnTechnology <- function(headers) {

  cTechnology = as.numeric(which(grepl("technology", headers$variables))[1])
  return(cTechnology)
}

#' Get the column number in powerplant data containing the location variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the location variable
#' @export
pColumnLocation <- function(headers) {

  cLocation = as.numeric(which(grepl("location", headers$variables))[1])
  return(cLocation)
}

#' Get the column number in powerplant data containing the age variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the age variable
#' @export
pColumnAge <- function(headers) {

  cAge = as.numeric(which(grepl("age", headers$variables))[1])
  return(cAge)
}

#' Get the column number in powerplant data containing the owner variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the owner variable
#' @export
pColumnOwner <- function(headers) {

  cOwner = as.numeric(which(grepl("owner", headers$variables))[1])
  return(cOwner)
}

#' Get the column number in powerplant data containing the capacity variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the capacity variable
#' @export
pColumnCapacity <- function(headers) {

  cCapacity = as.numeric(which(grepl("capacity", headers$variables))[1])
  return(cCapacity)
}

#' Get the column number in powerplant data containing the efficiency variable
#'
#' @param headers column containing headers of the data set
#' @return the column number in data containing the efficiency variable
#' @export
pColumnEfficiency <- function(headers) {

  cEfficiency = as.numeric(which(grepl("efficiency", headers$variables))[1])
  return(cEfficiency)
}
