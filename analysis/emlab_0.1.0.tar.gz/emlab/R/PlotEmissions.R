# -----------------------------------------------------------------------------------
# MAIN FUNCTION: Decision logic for CO2 emissions plotting
# -----------------------------------------------------------------------------------

#' Plot CO2 emissions over a simulation in a ribbon plot
#' @description Example query: PlotEmissions(data)
#' @param data Dataframe of which to take emission data.
#' @return Saves plots in workspace automatically.
#' @return Also a ggplot object. Can be stored and accessed by user for further ggplot manipulation.
#' @export
PlotCO2Emissions <- function(data) {

  headers = GetHeaders(data)
  nMarkets = NumberMarkets(headers)

  if(nMarkets == 1) {
    PlotEmissionsOneMarket(data, headers)
  }  else {
    PlotEmissionsTwoMarket(data, headers)
  }
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 1: One market
# -----------------------------------------------------------------------------------

PlotEmissionsOneMarket <- function(data, headers) {

  cIter = ColumnIteration(headers)
  cTick = ColumnTicks(headers)
  cEmissions = ColumnEmissionsCO2(headers)
  vMarket = VectorMarkets(headers)
  sData <- data[,c(cIter,cTick, cEmissions)]

  # Retrieve values for min, max and average and add them to dataframe 'pData'
  min <- aggregate.data.frame(sData,by=list(sData$tick), FUN = min, na.rm = TRUE)
  max <- aggregate.data.frame(sData,by=list(sData$tick), FUN = max, na.rm = TRUE)
  pData <- aggregate.data.frame(sData,by=list(sData$tick), FUN = mean, na.rm = TRUE)
  pData["min"] <- min[4]
  pData["max"] <- max[4]

  plotname = paste("Total CO2 emissions in ", vMarket[1], sep="")
  title = paste("Total CO2 emissions in ", vMarket[1], sep="")
  xlabel = "Tick (year)"
  ylabel = "CO2 emission (tonnes)"

  # Create plot
  plotobject <- ggplot(pData, aes(x=tick, y=pData[[4]], ymin=min, ymax=max)) +
    geom_ribbon(fill="dodgerblue", alpha=.6) +
    geom_line(colour="black", size=1) +
    labs(title =title, y=ylabel, x=xlabel) +
    theme_minimal()

  ggsave(paste(plotname, ".png",sep=""), plot=plotobject, width=8, height=5)
  message(paste("Plot '", plotname, "' added to your working directory", sep=""))

  return(plotobject)
}

# -----------------------------------------------------------------------------------
# SUB-FUNCTION 2: Two markets
# -----------------------------------------------------------------------------------

PlotEmissionsTwoMarket <- function(data, headers) {

  cIter = ColumnIteration(headers)
  cTick = ColumnTicks(headers)
  cEmissions = ColumnEmissionsCO2(headers)
  nMarkets = NumberMarkets(headers)
  vMarkets = VectorMarkets(headers)
  sData <- data[,c(cIter,cTick, cEmissions)]

  # Retrieve values for min, max and average and add them to dataframe 'pData'
  min <- aggregate.data.frame(sData,by=list(sData$tick), FUN = min, na.rm = TRUE)
  max <- aggregate.data.frame(sData,by=list(sData$tick), FUN = max, na.rm = TRUE)
  pData <- aggregate.data.frame(sData,by=list(sData$tick), FUN = mean, na.rm = TRUE)
  pData["min"] <- min[4]
  pData["max"] <- max[4]

  plotname = paste("Total CO2 emissions in ", vMarkets[1], " and ", vMarkets[2], sep="")
  title = paste("Total CO2 emissions in ", vMarkets[1], " and ", vMarkets[2], sep="")
  xlabel = "Tick (year)"
  ylabel = "CO2 emission (tonnes)"

  # Create plot
  plotobject <- ggplot(pData, aes(x=tick, y=pData[[4]], ymin=min, ymax=max)) +
    geom_ribbon(fill="dodgerblue", alpha=.6) +
    geom_line(colour="black", size=1) +
    labs(title =title, y=ylabel, x=xlabel) +
    theme_minimal()

  ggsave(paste(plotname, ".png",sep=""), plot=plotobject, width=8, height=5)
  message(paste("Plot '", plotname, "' added to your working directory", sep=""))

  return(plotobject)
}



